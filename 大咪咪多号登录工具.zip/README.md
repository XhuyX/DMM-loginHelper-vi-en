# DMM-loginHelper
dmm游戏多账号登录

在setting中添加删除游戏，具体的名称以deepone为例：  
PC浏览器端的游戏地址为，http://pc-play.games.dmm.co.jp/play/deeponer/  
那么填入setting的游戏名即为该url中"play"后面的  

登录相关的代码来自沖田KENC